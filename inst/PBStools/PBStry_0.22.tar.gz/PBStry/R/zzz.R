.First.lib <- function(lib, pkg) {
  library.dynam("PBStry", pkg, lib);
  cat(
"PBS Try 0.22  Copyright (C) 2006 Fisheries and Oceans Canada\
\
PBS Try comes with ABSOLUTELY NO WARRANTY, but it does provide a\
handy prototype for R model development. It includes the use of\
C source code, with .C function calls.
\
Usage notes:\
Data sets in a package must be loaded with R's 'data' function.\
Type '?data' for further information.\n");
}
