# ***********************************************************
#pause - Pause between graphics displays and other analyses
# -----------------------------------------------------------
pause <- function (s = "Press <Enter> to continue") {
  cat(s); readline(); invisible(); }
